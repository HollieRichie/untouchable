package com.example.ACsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcSecurityApplication.class, args);
	}

}
